﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;


public partial class Farmer_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection("Data Source=LAPTOP-1P4VELIR;Initial Catalog=db_pinapplefarm;Integrated Security=True");
    static int idNo;
    protected void Page_Load(object sender, EventArgs e)
    {
        con.Open();
        string farmerID = Session["farmerid"].ToString();
        if (farmerID != null)
        {

        }
        else
        {
            Response.Redirect("../Guest/Login.aspx");
        }
    }
    protected void btnsend_Click(object sender, EventArgs e)
    {
        idNo = Convert.ToInt32(Session["farmerid"].ToString());
        string insQry = "insert into tbl_complaint(farmer_id,complaint_title,complaint_content,complaint_date) values('" + idNo + "','" + txttitle.Text + "','" + txtcomplaint.Text + "','"+DateTime.Now.ToShortDateString()+"')";
        SqlCommand cmd = new SqlCommand(insQry, con);
        cmd.ExecuteNonQuery();

    }
    protected void btncancel_Click(object sender, EventArgs e)
    {
        txttitle.Text = "";
        txtcomplaint.Text = "";
      
    }
}